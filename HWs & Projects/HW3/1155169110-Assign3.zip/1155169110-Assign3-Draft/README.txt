The clustered result may depend on the selection of random initial centroids. 
Sometimes when the iteration number increase, the clustered labels will go to only a few labels. 
For example, when K = 8, the clustered labels may only contain label 2 and label 4.